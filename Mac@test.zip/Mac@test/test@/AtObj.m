//
//  AtObj.m
//  test@
//
//  Created by pengwenjie on 16/8/3.
//  Copyright © 2016年 彭文杰. All rights reserved.
//

#import "AtObj.h"

@implementation AtObj

- (NSString *)description
{
    return [NSString stringWithFormat:@"%@",NSStringFromRange(_range)];
}

@end
