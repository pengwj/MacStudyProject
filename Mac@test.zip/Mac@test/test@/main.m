//
//  main.m
//  test@
//
//  Created by darkwing90s on 16/7/28.
//  Copyright © 2016年 彭文杰. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
